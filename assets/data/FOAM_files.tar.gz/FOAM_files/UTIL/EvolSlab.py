#
#  This script takes individual month netcdf history
#  files produced by FOAM and concatenates them into
#  merged netcdf files. It needs to be prettied up,
#  adding a scan of what's in the directory and user prompts.
#  For now, you edit the start year (or the last year simulated before) and the number of years 
#  to merge in the script below. Also, there should be
#  a check that it won't inadvertently overwrite something
#     
from os import system
prefix = 'history.atmos.'
year = 0 
nyears = 100 
conc = ''
files = ''
Final_name = prefix+"evol.an"+"%03d"%(year+1)+"a"+"%03d"%(year+nyears)+".nc"
for i in range(year*360,(year+nyears)*360,360):
  files = ''
  for j in range(1,13,1):
    ind = i + 30*j
    files += prefix+"%07d"%ind+".nc "
    ade = ind/360
    OutFile = prefix+"an"+"%03d"%ade+".nc"
  command = 'ncra ' + files + ' '+ OutFile
  system(command)
  conc += OutFile+' ' 	
#command = 'ncrcat ' + conc + ' '+ Final_name
command = 'ncrcat ' + conc + ' '+ Final_name
system(command)
 

