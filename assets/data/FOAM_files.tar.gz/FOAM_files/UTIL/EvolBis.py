#
#  This script takes individual month netcdf history
#  files produced by FOAM and concatenates them into
#  merged netcdf files. It needs to be prettied up,
#  adding a scan of what's in the directory and user prompts.
#  For now, you edit the start year (or the last year simulated before) and the number of years 
#  to merge in the script below. Also, there should be
#  a check that it won't inadvertently overwrite something
#     
from os import system
prefix = 'history.ocean.'
year = 0 
nyears = 2000 
conc = ''
files = ''
Final_name = prefix+"evol.an"+"%03d"%(year+1)+"a"+"%03d"%(year+nyears)+".nc"
for i in range((year+1)*360,(year+1+nyears)*360,360):
#  files = ''
#  for j in range(1,13,1):
#    ind = i + 30*j
#    files += prefix+"%07d"%ind+".nc "
  ade = i
  OutFile = prefix+"%07d"%ade+".nc"
#  command = 'ncra ' + files + ' '+ OutFile
#  system(command)
  conc += OutFile+' ' 	
#command = 'ncrcat ' + conc + ' '+ Final_name
command = 'ncrcat -v T,S,V ' + conc + ' '+ Final_name
system(command)
command2 = 'ncrename -v T,TEMP' + ' ' + Final_name
system(command2)
 

