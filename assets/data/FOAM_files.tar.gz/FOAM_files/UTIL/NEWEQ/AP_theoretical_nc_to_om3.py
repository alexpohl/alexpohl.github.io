#!/usr/bin/env python
# 11 May 2020
# adapting JY's script to avoid using cdms2

import numpy
import netCDF4
from netCDF4 import Dataset

f_name = 'out.nc'
v_name = 'THETA'

out_file = 'om3.temp24_23_8_1_1'

#f1 = cdms2.open(f_name)
#theta = f1(v_name)
#f1.close()

f1=Dataset(f_name)
theta = f1.variables[v_name][:]
f1.close()

g = open(out_file, 'wb')
v_write = theta * 100 + 10000
g.write(v_write.astype(numpy.int16).byteswap().tostring())
g.close()

# Plot a vertical/lat plot
#x = vcs.init()
#x.plot(theta[:, :, 0])

# Plot SST
#y = vcs.init()
#y.plot(theta[23,:,:])

# The end


