%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Alexandre Pohl, Mai, 13, 2015
%% Creates a theoretical latitudinal profile for input om3.temp24 file
%%
%% Latitudinal theta profile function from Jean-Baptiste Ladant
%% /home/dataclimber/jbladant/IPSL-CM5/CREATE_BC_IPSLCM5A/modtempideal.f90
%%
%% Output at 0.1 degre resolution in order to facilitate further interpolation on FOAM grid

clear
close all


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Tequ='23.0';     % Tequator = Tmax
Tthermo='8.0';   % Tthermocline
Tpolar='1.0';    % Tpole
Tbottom='1.0';     % Tbottom
latmax=90.;   % max latitude
sigma=360.;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



Teq = str2num(Tequ);
Tpole = str2num(Tpolar);
Tbot = str2num(Tbottom);
Ttherm = str2num(Tthermo);


% ----------------------------------------------------------------------------
% vertical levels

%       K     Z                   ZBOX      ZBOXLO
%       1>  -5300                 400        -5500
%       2>  -4900                 400        -5100
%       3>  -4500                 400        -4700
%       4>  -4100                 400        -4300
%       5>  -3700                 400        -3900
%       6>  -3300                 400        -3500
%       7>  -2900                 400        -3100
%       8>  -2500                 400        -2700
%       9>  -2100                 400        -2300
%      10>  -1700                 396.25     -1900
%      11>  -1307.5               373.75     -1503.75
%      12>  -952.5                316.25     -1130
%      13>  -675                  234.25     -813.75
%      14>  -484                  159        -579.5
%      15>  -357                  106.5      -420.5
%      16>  -271                  73.5       -314
%      17>  -210                  53         -240.5
%      18>  -165                  40.5       -187.5
%      19>  -129                  32.75      -147
%      20>  -99.5                 27.5       -114.25
%      21>  -74                   24.25      -86.75
%      22>  -51                   22         -62.5
%      23>  -30                   20.5       -40.5
%      24>  -10                   20         -20

center_depth=[-10. -30. -51. -74. -99.5 -129. -165. -210. -271. -357. -484. -675. -952.5 -1307.5 -1700. -2100. -2500. -2900. -3300. -3700. -4100. -4500. -4900. -5300.];

ktherm=11.;     % vertical level so that thermocline <=> 500 m
% maximum depth ?
pmax = -4000; % max depth used in the simulation
% thermocline depth ?
ptherm = -579.5;

nz = length(center_depth);



% ----------------------------------------------------------------------------
% THETA file initialisation

Topovalue2 = ones(128,128,nz);

latitude_tmp1 = [89.297:-1.40625:0.703]; % latitude must be positive, even in the SH
latitude_tmp2 = [0.703:1.40625:89.297]; % NH
latitude_tmp1_op = -1 * latitude_tmp1; % SH latitude back to negative values
latitude_tmp  = [latitude_tmp1_op latitude_tmp2]; % latitude axis for netcdf
longitude_tmp = [1.40625:2.8125:358.5938]; % longitude axis for netcdf

latitude = [];
for i = 1:128
   latitude = [latitude; latitude_tmp]; % needed to calculate 3D THETA field
end

% calculating the theoretical 3D THETA field

for k = 1:nz
   for j = 1:128
      for i = 1:128
         if (k <= ktherm)
             Topovalue2(i,j,k)=(center_depth(k)/(ptherm*(1-exp(-((latmax^2)/(sigma^2))))))*((Tpole-Teq)*exp(-((latitude(i,j)^2)/(sigma^2)))+Ttherm*(1-exp(-((latmax^2)/(sigma^2))))+Teq*exp(-((latmax^2)/(sigma^2)))-Tpole)+(1/(1-exp(-((latmax^2)/(sigma^2)))))*((Teq-Tpole)*exp(-((latitude(i,j)^2)/(sigma^2)))+Tpole-Teq*exp(-((latmax^2)/(sigma^2))));
         else
             Topovalue2(i,j,k)=((Tbot-Ttherm)/(pmax-ptherm))*(center_depth(k)-ptherm)+Ttherm;
         end
      end
   end
end



% ----------------------------------------------------------------------------
%  saving to netcdf file

fname = 'out.nc';
test = exist(fname,'file');
if (test ~= 0)
    delete(fname);
end

nccreate(fname,'THETA',...
          'Dimensions',{'lon',128, 'lat',128,'lev',nz},...
          'Format','netcdf4_classic');
ncwrite(fname,'THETA', Topovalue2);

nccreate(fname,'lat',...
          'Dimensions',{'lat',128},...
          'Format','netcdf4_classic');
ncwrite(fname,'lat', latitude_tmp);
ncwriteatt(fname,'lat','long_name','latitude');
ncwriteatt(fname,'lat','units','degrees_north');

nccreate(fname,'lon',...
          'Dimensions',{'lon',128},...
          'Format','netcdf4_classic');
ncwrite(fname,'lon', longitude_tmp);
ncwriteatt(fname,'lon','long_name','longitude');
ncwriteatt(fname,'lon','units','degrees_east');

nccreate(fname,'lev',...
          'Dimensions',{'lev',nz},...
          'Format','netcdf4_classic');
ncwrite(fname,'lev', center_depth);
ncwriteatt(fname,'lev','long_name','ocean depth');
ncwriteatt(fname,'lev','units','meters');
ncwriteatt(fname,'lev','axis','Z');





