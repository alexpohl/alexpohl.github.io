# Alexandre Pohl, Oct 16 2019
# Checks for equilibrium in FOAM runs
# ... by plotting the temperature in the water column as a function of time
# ... and computing the temperature drift in the deep ocean over the last 1000 years

# 19 Nov. 2019: ocnareamat_tropics corrected for nan in ocean fields

import matplotlib as mpl
from collections import OrderedDict
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.ticker as mticker
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
import numpy as np
import string
from matplotlib.colors import BoundaryNorm
import math
from matplotlib import patches
import netCDF4
from netCDF4 import Dataset
import sys

################# INPUT BLOCK #################
dirpath = '/work/crct/zz9999zz/foam/phanero/300rd/300rd_T37/EcN_8X/history/ocean/'
# '/' at the end
nyears = 2000

do_fig = 'y'
save_fig = 'y'
show_fig = 'y'
##############################################

# reading every nyears
everynyear = 20



# nothing to change below this line



# standard frontend instead of web interface
mpl.use('TkAgg')
# graphical options
plot_font_size = 13
plot_label_size = plot_font_size+3
mpl.rc('font', size=plot_font_size+7)
# for the figure
figXsize = 8
figYsize = 6
# for the annotations on the maps
xlabel = 0
ylabel = 1.05

# functions
functionstoload = ['areafun','fakealpha','custom_colormaps','custom_chars']
for function2load in functionstoload:
    string2execute = '/archive/crct/al1966po/ressources/python_custom_functions/' + function2load + '.py'
    exec(open(string2execute).read()) # python 3


##########################################################################
# =============== PART 1 :: COMPUTING REQUESTED QUANTITIES ===============
##########################################################################

# filename
historypath = dirpath + '/' + 'history.ocean.evol.an001a' + str(nyears) + '.nc'

# reading nc file
iyears = np.arange(-everynyear-1,nyears+everynyear,everynyear)[1:-1]; iyears[0] = 0 # indices, starting at 0 ... 1999
years = iyears + 1 # years, starting at 1 ... 2000
print('Loading netcdf file...')
f=Dataset(historypath)
fulltemp = f.variables['TEMP'][:] # (2000, 24, 128, 128)
lat = f.variables['lat'][:]
lon = f.variables['lon'][:]
lev = f.variables['lev'][:]
f.close()

# extracting time slices of interest (one every everynyear):
masked_temp = fulltemp[iyears,:,:,:]
temp = np.where(masked_temp.mask==True,np.nan,masked_temp) 
# array of grid point area
areamat = area(lon,lat,'') # m2

# computing mean 
lengthT, lengthZ, lengthX, lengthY = np.shape(temp) # (200, 24, 128, 128)
homvol = np.full((lengthZ, lengthT), np.nan) # (24, 200)
for t in np.arange(lengthT):
    print('Computing year ' + str(years[t]))
    for z in np.arange(lengthZ):
        areamat_ocnonly = np.ma.masked_where(np.isnan(temp[t,z,:,:]),areamat)
        summ = np.nansum(np.multiply(temp[t,z,:,:],areamat_ocnonly))
        if summ == 0: # nansum treats np.nan as zero ; a sum of 0 is just meaning it s full of nan
            homvol[z, t] = np.nan
        else:
            homvol[z, t] = np.nansum(np.multiply(temp[t,z,:,:],areamat_ocnonly))/np.sum(areamat_ocnonly)

# drift in the deep ocean over the last 100 years lev[4] = -3700 (mid point of last level then)
lastyear = years[-1]
firstyear = lastyear  - 100
ix_firstyear = np.where(years == firstyear) # years[ix_firstyear] OK !
drift100lastyears = np.asscalar(homvol[4,-1] - homvol[4,ix_firstyear]) # array to scalar
annotation = str(round(drift100lastyears,3)) + degree_sign + 'C over the last 100 years at -3700 m'

##########################################################################
# =============== PART 2 :: PLOTTING ===============
##########################################################################

if do_fig == 'y':

    # min and max (integers covering the whole range of values)
    mini = np.nanmin(homvol)
    vmin = int(mini)
    if vmin > mini:
        vmin -= 1
    maxi = np.nanmax(homvol)
    vmax = int(maxi)
    if vmax < maxi:
        vmax += 1

    # colormap limits
    clevs = np.arange(vmin,vmax+1E-3,0.5) # 1E-3 is just to include the upper bound

    print('Plotting')
     
    fig =  plt.figure(figsize=(figXsize, figYsize))
    ax = fig.add_subplot(111)
    ax = fig.gca()
    cf = plt.contourf(years, lev, homvol, clevs, cmap = light_centered)
    c = plt.contour(years, lev, homvol, clevs, cmap = None, colors='k',linewidths=0.5)
    plt.annotate(annotation, xy=(xlabel, ylabel), xycoords='axes fraction',fontsize=plot_font_size)
    cb = fig.colorbar(cf, orientation='horizontal')
    ax.set_xlim([0,nyears])
    ax.set_ylim([-4000,0])
    plt.xticks(fontsize=plot_font_size)
    plt.yticks(fontsize=plot_font_size)
    cb.ax.tick_params(labelsize=plot_font_size)

    if save_fig == 'y':
        fname = dirpath[38:54] + '_evol_year0to' + str(nyears) + '.png'; fname = fname.replace('/','_')  
        print('Saving output as ' + fname)
        plt.savefig(fname,format='png')

    if show_fig == 'y':
        plt.show()


################################ The End ################################
