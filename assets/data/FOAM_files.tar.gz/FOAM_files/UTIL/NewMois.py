#
#  This script takes individual month netcdf history
#  files produced by FOAM and averages them into
#  merged netcdf files. It needs to be prettied up,
#  adding a scan of what's in the directory and user prompts.
#  For now, you edit the start year (minus 1) and the number of years 
#  to merge in the script below. Also, there should be
#  a check that it won't inadvertently overwrite something
#     
from os import system
prefix = 'history.ocean.' 
year = 2000 
nyears = 50 
post = 'an'+"%02d"%(year+1)+"a"+"%02d"%(year+nyears)+".m"
pree = '01a12.nc'
files = ''
endlist = ''
endname ='300rd_1368W_EccN_ocean_2240ppm.nc'
toto = 'mois.an'
  
for i in range(year*360,(year+nyears)*360,360):
  files=''
  for j in range(1,13,1):
    ind=i+j*30
    files += prefix+"%07d"%ind+".nc "
  OutFileName = prefix+toto+"%03d"%((i/360)+1)+".nc"
  command = 'ncrcat -O ' + files + ' '+ OutFileName
  system(command)
  endlist += OutFileName+' '
command = 'ncea ' + endlist + ' '+ endname
system(command)
if 'ocean' in prefix:
    command2 = 'ncrename -v T,TEMP ' + endname
    system(command2)
